import { useEffect, useMemo, useState, useCallback } from 'react';
import * as anchor from '@project-serum/anchor';

import styled from 'styled-components';
import { Container, Snackbar, makeStyles, Box,
	List,
	ListItem,
	Typography } from '@material-ui/core';
import Paper from '@material-ui/core/Paper';
import Alert from '@material-ui/lab/Alert';
import { PublicKey } from '@solana/web3.js';
import { useWallet } from '@solana/wallet-adapter-react';
import { WalletDialogButton } from '@solana/wallet-adapter-material-ui';
import {
  awaitTransactionSignatureConfirmation,
  CandyMachineAccount,
  CANDY_MACHINE_PROGRAM,
  getCandyMachineState,
  mintOneToken,
} from './candy-machine';
import { AlertState } from './utils';
import { Header } from './Header';
import { MintButton } from './MintButton';
import { GatewayProvider } from '@civic/solana-gateway-react';

const ConnectButton = styled(WalletDialogButton)`
  width: 100%;
  height: 60px;
  margin-top: 10px;
  margin-bottom: 5px;
  background: linear-gradient(180deg, #604ae5 0%, #813eee 100%);
  color: white;
  font-size: 16px;
  font-weight: bold;
`;

const MintContainer = styled.div``; // add your owns styles here

export interface HomeProps {
  candyMachineId?: anchor.web3.PublicKey;
  connection: anchor.web3.Connection;
  startDate: number;
  txTimeout: number;
  rpcHost: string;
}

const useStyles = makeStyles((theme) => ({
	home: {
		background:
			"linear-gradient(180deg,#3e2696 30%,#351e8a 0,#351e8a 70%,#472ea5 0)",
		color: "#FFF",
		height: "100vh",
		borderRadius: "0",
		boxShadow: "none",
		position: "relative",
		[theme.breakpoints.between("xs", "sm")]: {
			minHeight: "100vh",
			height: "100%",
		},
	},
	box: {
		backgroundColor: "#1D0575",
		borderRadius: "25px",
		position: "absolute",
		height: "calc(100vh - 200px)",
		top: "50%",
		transform: "translateY(-50%)",
		width: "calc(100% - 32px)",
		[theme.breakpoints.between("xs", "sm")]: {
			position: "relative",
			height: "100%",
			width: "100%",
			top: "0",
			transform: "none",
		},
	},
	listTedy: {
		height: "calc(100vh - 200px)",
		display: "flex",
		[theme.breakpoints.between("xs", "sm")]: {
			width: "100%",
			height: "100%",
			flexWrap: "wrap",
		},
	},
	imgTedy: {
		height: "100%",
		minWidth: "250px",
		maxWidth: "100%",
		objectFit: "cover",
		borderRadius: `25px 0 0 25px`,
		[theme.breakpoints.between("xs", "sm")]: {
			borderRadius: `25px 25px 0 0`,
			width: "100%",
		},
	},
	listInfo: {
		display: "flex",
		flexDirection: "column",
		minWidth: "300px",
	},
	"listInfoItem:not(:last-child)": {
		marginBottom: "5px",
		borderBottom: "1px solid #6049b0;",
	},
	buttonWall: {
		width: "100%",
		height: "60px",
		marginTop: "10px",
		marginBottom: "5px",
		background: "linear-gradient(180deg, #604ae5 0%, #813eee 100%)",
		color: "white",
		fontSize: "16px",
		fontWeight: "bold",
	},
	container: {
		[theme.breakpoints.down("sm")]: {
			width: "100%",
		},
		[theme.breakpoints.up("md")]: {
			width: "100%",
		},
		[theme.breakpoints.up("lg")]: {
			width: "960px",
		},
		[theme.breakpoints.up("xl")]: {
			width: "1200px",
		},
	},
	botText: {
		textAlign: "center",
		position: "absolute",
		bottom: "50px",
		left: "50%",
		width: "fit-content",
		transform: "translateX(-50%)",
		[theme.breakpoints.between("xs", "sm")]: {
			position: "relative",
			bottom: "0",
			left: "0",
			transform: "none",
			marginTop: "20px",
		},
	},
}))

const Home = (props: HomeProps) => {
  const styles = useStyles()
  const [isUserMinting, setIsUserMinting] = useState(false);
  const [candyMachine, setCandyMachine] = useState<CandyMachineAccount>();
  const [alertState, setAlertState] = useState<AlertState>({
    open: false,
    message: '',
    severity: undefined,
  });

  const rpcUrl = props.rpcHost;
  const wallet = useWallet();

  const anchorWallet = useMemo(() => {
    if (
      !wallet ||
      !wallet.publicKey ||
      !wallet.signAllTransactions ||
      !wallet.signTransaction
    ) {
      return;
    }

    return {
      publicKey: wallet.publicKey,
      signAllTransactions: wallet.signAllTransactions,
      signTransaction: wallet.signTransaction,
    } as anchor.Wallet;
  }, [wallet]);

  const refreshCandyMachineState = useCallback(async () => {
    if (!anchorWallet) {
      return;
    }

    if (props.candyMachineId) {
      try {
        const cndy = await getCandyMachineState(
          anchorWallet,
          props.candyMachineId,
          props.connection,
        );
        setCandyMachine(cndy);
      } catch (e) {
        console.log('There was a problem fetching Candy Machine state');
        console.log(e);
      }
    }
  }, [anchorWallet, props.candyMachineId, props.connection]);

  const onMint = async () => {
    try {
      setIsUserMinting(true);
      document.getElementById('#identity')?.click();
      if (wallet.connected && candyMachine?.program && wallet.publicKey) {
        const mintTxId = (
          await mintOneToken(candyMachine, wallet.publicKey)
        )[0];

        let status: any = { err: true };
        if (mintTxId) {
          status = await awaitTransactionSignatureConfirmation(
            mintTxId,
            props.txTimeout,
            props.connection,
            true,
          );
        }

        if (status && !status.err) {
          setAlertState({
            open: true,
            message: 'Congratulations! Mint succeeded!',
            severity: 'success',
          });
        } else {
          setAlertState({
            open: true,
            message: 'Mint failed! Please try again!',
            severity: 'error',
          });
        }
      }
    } catch (error: any) {
      let message = error.msg || 'Minting failed! Please try again!';
      if (!error.msg) {
        if (!error.message) {
          message = 'Transaction Timeout! Please try again.';
        } else if (error.message.indexOf('0x137')) {
          message = `SOLD OUT!`;
        } else if (error.message.indexOf('0x135')) {
          message = `Insufficient funds to mint. Please fund your wallet.`;
        }
      } else {
        if (error.code === 311) {
          message = `SOLD OUT!`;
          window.location.reload();
        } else if (error.code === 312) {
          message = `Minting period hasn't started yet.`;
        }
      }

      setAlertState({
        open: true,
        message,
        severity: 'error',
      });
    } finally {
      setIsUserMinting(false);
    }
  };

  useEffect(() => {
    refreshCandyMachineState();
  }, [
    anchorWallet,
    props.candyMachineId,
    props.connection,
    refreshCandyMachineState,
  ]);

  return (
    <Container style={{ marginTop: 100 }}>
      <Container maxWidth="xs" style={{ position: 'relative' }}>
        <Paper
          style={{ padding: 24, backgroundColor: '#151A1F', borderRadius: 6 }}
        >
          {!wallet.connected ? (
            <Paper className={styles.home}>
              <Container
                maxWidth={false}
                className={styles.container}
                disableGutters
                style={{
                  position: "relative",
                  height: "100%",
                  padding: "30px 16px",
                }}>
                <Box className={styles.box}>
                  <List className={styles.listTedy} disablePadding>
                    <ListItem
                      disableGutters
                      style={{ height: "100%", width: "100%", padding: "0" }}>
                      <img
                        src='/img/tedy.jpg'
                        alt='tedy'
                        className={styles.imgTedy}
                      />
                    </ListItem>
                    <ListItem style={{ justifyContent: "center" }}>
                      <List className={styles.listInfo}>
                        <ListItem className={styles["listInfoItem:not(:last-child)"]}>
                        <ConnectButton>Connect Wallet</ConnectButton>
                        </ListItem>
                        <ListItem className={styles["listInfoItem:not(:last-child)"]}>
                          <Typography
                            variant='h6'
                            component='div'
                            style={{ display: "flex", width: "100%" }}>
                            Price: <span style={{ marginLeft: "auto" }}>1 SOL</span>
                          </Typography>
                        </ListItem>
                        <ListItem className={styles["listInfoItem:not(:last-child)"]}>
                          <Typography
                            variant='h6'
                            component='div'
                            style={{ display: "flex", width: "100%" }}>
                            Remaining:{" "}
                            <span style={{ marginLeft: "auto" }}>1 SOL</span>
                          </Typography>
                        </ListItem>
                      </List>
                    </ListItem>
                  </List>
                </Box>
                <Typography variant='h5' component='h2' className={styles.botText}>
                  Please make sure you connect your SOL wallet to Mint.
                </Typography>
              </Container>
            </Paper>
          ) : (
            <>
              <Header candyMachine={candyMachine} />
              <MintContainer>
                {candyMachine?.state.isActive &&
                candyMachine?.state.gatekeeper &&
                wallet.publicKey &&
                wallet.signTransaction ? (
                  <GatewayProvider
                    wallet={{
                      publicKey:
                        wallet.publicKey ||
                        new PublicKey(CANDY_MACHINE_PROGRAM),
                      //@ts-ignore
                      signTransaction: wallet.signTransaction,
                    }}
                    gatekeeperNetwork={
                      candyMachine?.state?.gatekeeper?.gatekeeperNetwork
                    }
                    clusterUrl={rpcUrl}
                    options={{ autoShowModal: false }}
                  >
                    <MintButton
                      candyMachine={candyMachine}
                      isMinting={isUserMinting}
                      onMint={onMint}
                    />
                  </GatewayProvider>
                ) : (
                  <MintButton
                    candyMachine={candyMachine}
                    isMinting={isUserMinting}
                    onMint={onMint}
                  />
                )}
              </MintContainer>
            </>
          )}
        </Paper>
      </Container>

      <Snackbar
        open={alertState.open}
        autoHideDuration={6000}
        onClose={() => setAlertState({ ...alertState, open: false })}
      >
        <Alert
          onClose={() => setAlertState({ ...alertState, open: false })}
          severity={alertState.severity}
        >
          {alertState.message}
        </Alert>
      </Snackbar>
    </Container>
  );
};

export default Home;
